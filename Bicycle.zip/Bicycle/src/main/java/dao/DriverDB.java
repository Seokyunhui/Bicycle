package dao;

import java.sql.*;

public class DriverDB {
	private static Connection conn;
	private static PreparedStatement pstmt;
	private static ResultSet rs;
	
	public DriverDB() {
		try {
			String jdbcDiver= "jdbc:mysql://localhost:3306/bicycle?" + "useUnicode=true&characterEncoding=euckr";
			String dbUser = "bicycleDBAdmin";
			String dbpw = "1234";
			Class.forName("com.mysql.jdbc.Driver");
			
			conn = DriverManager.getConnection(jdbcDiver, dbUser, dbpw);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public int Member_login(String id, String pw) {
		String strQuery = "SELECT Member_pw FROM member WHERE Member_id =?";
		
		try {
			pstmt = conn.prepareStatement(strQuery);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getString("Member_pw").equals(pw)) {
					return 1; // �α��� ����
				}else {
					return 0;	// ��й�ȣ ����ġ
				}
			}			
			return -1;	// ���̵����
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return -2;	// �����ͺ��̽� ������ �ǹ�
	}
}
